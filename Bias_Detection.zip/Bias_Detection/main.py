# Import Libraries
import tensorflow as tf
import pandas as pd
import numpy as np
import os
from os import path
from transformers import AutoConfig, AutoTokenizer, AutoModelForSequenceClassification
from sklearn.model_selection import train_test_split
from sklearn.metrics import *
from transformers import BertTokenizer
from transformers import TFBertModel
from tensorflow.keras.layers import Flatten,Input, Dense, GlobalAveragePooling1D, GlobalMaxPooling1D, Dropout, LSTM, Bidirectional, Concatenate
from tensorflow.keras.models import Model
from tensorflow.keras.callbacks import Callback
from sklearn.utils.class_weight import compute_class_weight

def load_data(path, text, label):
    # Load Dataset
    dataset = pd.read_excel(path)
    dataset = dataset[[text,label]]
    dataset.dropna(inplace=True)

    # Label Encoding
    dataset[label].replace('bias',1,inplace=True)
    dataset[label].replace('nobias',0,inplace=True)
    
    # The list of all tweet sentences
    X = list(dataset[text])

    # The list of all labels
    y = list(dataset[label])
    return X, y

# Compile Model
class MetricsCallback(Callback):
    def __init__(self, test_data, y_true, name):
        self.y_true = y_true
        self.test_data = test_data
        self.f1 = 0
        self.name = name

    def on_epoch_end(self, epoch, logs=None):
         y_pred = self.model.predict(self.test_data)
         y_pred = tf.argmax(y_pred,axis=1)
        #  report_dictionary = classification_report(self.y_true, y_pred, output_dict = True)
        #  print(classification_report(self.y_true,y_pred,output_dict=False))
        #  print(confusion_matrix(self.y_true,y_pred))
         if f1_score(self.y_true,y_pred)>self.f1:
            self.f1 = f1_score(self.y_true,y_pred)
            self.model.save(self.name)

def train(data_path='./bias-sample data1.xlsx', text='tweet', label='label'):
    X, y = load_data(data_path, text='tweet', label='label')    

    # Train Test Split
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.1, shuffle=True, stratify=y)

    # Load Bert Model
    # Call the ParsBert Pre-trained Model and Tokenizer from HuggingFace

    ParsBert_model_name_and_path = "HooshvareLab/bert-fa-zwnj-base"    # This is the path of ParsBert Version 3
    config = AutoConfig.from_pretrained(ParsBert_model_name_and_path)
    tokenizer = AutoTokenizer.from_pretrained(ParsBert_model_name_and_path)
    model = AutoModelForSequenceClassification.from_pretrained(ParsBert_model_name_and_path, num_labels=2)

    # Tokenize Train data
    d = tokenizer(X_train,max_length = 128,padding = 'max_length',truncation = True)

    # Features or BERT encodings
    q = np.array(d['input_ids'])
    q1 = np.array(d['attention_mask'])

    # model=TFBertModel.from_pretrained('bert-base-uncased')
    model=TFBertModel.from_pretrained("HooshvareLab/bert-fa-zwnj-base")

    # Create Model
    inp1=Input(shape=(128,),dtype='int32')
    inp2=Input(shape=(128,),dtype='int32')
    emb=model(inp1, attention_mask=inp2)[0]
    l=Bidirectional(LSTM(32,return_sequences=True))(emb)
    # l=Bidirectional(LSTM(32,return_sequences=True))(l)
    # l = LSTM(128,return_sequences=True)(emb)
    # l = LSTM(16,return_sequences=True)(l)
    la = GlobalMaxPooling1D()(l)
    l = GlobalAveragePooling1D()(l)
    # la = Flatten()(l)
    # l = Flatten()(l)
    l=Concatenate()([l,la])
    l=Dense(128,activation='relu')(l)
    l=Dense(64,activation='relu')(l)
    l=Dropout(0.5)(l)
    l=Dense(2,activation='softmax')(l)
    m=Model(inputs=[inp1,inp2],outputs=l)

    # Tokenize Test data
    d1 = tokenizer(X_test,max_length=128,padding='max_length',truncation=True)
    q2=np.array(d1['input_ids'])
    q3=np.array(d1['attention_mask'])

    # freeze bert part
    model.trainable=False    
    name = input_data_dir.split('/')[-1].split('.')[0]+'.hd5'
    metrics_callback = MetricsCallback(test_data=[q2,q3], y_true=y_test,name=name)

    weights = compute_class_weight(class_weight = "balanced", classes= np.unique(y), y= y)
    m.compile(optimizer=tf.keras.optimizers.RMSprop(),
                  loss=tf.keras.losses.SparseCategoricalCrossentropy(),
                  loss_weights=weights,
                  metrics=['accuracy'],
                  steps_per_execution=32)
    
    class_weight = {0:weights[0],
                    1:weights[1]}

    history = m.fit([q,q1],np.array(y_train),
          epochs=2,
          validation_data=([q2,q3],np.array(y_test)),
          callbacks=[metrics_callback],
          batch_size=32,
          class_weight=class_weight)

    model = tf.keras.models.load_model(
        path.join(name),
        custom_objects={"TFBertModel": TFBertModel}
    )

    res1 = m.predict([q2,q3])
    p = np.argmax(res1,axis=1)
    print(classification_report(y_test,p,digits=3))
    cm = confusion_matrix(y_test,p)
    print(cm)

    return m

def inference(model_name, input_txt):
    ParsBert_model_name_and_path = "HooshvareLab/bert-fa-zwnj-base"    # This is the path of ParsBert Version 3
    config = AutoConfig.from_pretrained(ParsBert_model_name_and_path)
    tokenizer = AutoTokenizer.from_pretrained(ParsBert_model_name_and_path)
    d1 = tokenizer(input_txt,max_length=128,padding='max_length',truncation=True)
    model = tf.keras.models.load_model(
        path.join(model_name),
        custom_objects={"TFBertModel": TFBertModel}
    )
    q2=np.array(d1['input_ids'])
    q3=np.array(d1['attention_mask'])
    q2=tf.expand_dims(q2,axis=0)
    q3=tf.expand_dims(q3,axis=0)

    res = model.predict([q2,q3])
    p = np.argmax(res,axis=1)[0]
    return 'bias' if p else 'nobias'


if __name__ == '__main__':
    input_data_dir = 'bias-sample data1.xlsx'

    FLAG = False
    input_txt = 'اره اینجا ایران و تهران خودمونه :)\n#مهسا_امینی https://t.co/dFSEybsnUW'
    model_name = input_data_dir.split('/')[-1].split('.')[0]+'.hd5'
    model_exist = os.path.exists(model_name)
    print(model_name)
    if model_exist:
        FLAG = True

    if FLAG:
        result = inference(model_name, input_txt)
        print(result)
    else:
        train(input_data_dir,text='tweet', label='label')
    
